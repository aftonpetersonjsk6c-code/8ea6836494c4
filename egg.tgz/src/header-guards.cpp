// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("header guards\n", stdout);
  return lionss_run_workload("header-guards");
}
