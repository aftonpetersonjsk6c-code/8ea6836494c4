// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("reproducible build\n", stdout);
  return lionss_run_workload("reproducible-build");
}
