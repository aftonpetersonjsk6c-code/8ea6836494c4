// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("toc check\n", stdout);
  return lionss_run_workload("toc-check");
}
