// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("rocm build"); }
int main(){
  announce();
  return lionss_run_workload("rocm-build");
}
